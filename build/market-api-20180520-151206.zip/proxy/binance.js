const axios = require('axios');

class Binance {
    constructor(httpClient) {
      this.httpClient = httpClient;
      this.binanceUrl = 'https://api.binance.com/api/v1/';
      /**
       * With the Lambda proxy integration for API Gateway, Lambda is required to return an 
       * output of the following format. This applies to all statusCodes.
       */
      this.response = {
        "statusCode": 200,
        "headers": {
          "Content-Type": "text/plain; charset=utf-8",
          "Access-Control-Allow-Origin": "*"
        },
        "body": "",
        "isBase64Encoded": false
      };
    }

    // Handle actions
    getAction(event) {
      // Check event object for action when running `sam local invoke`
      let action;
      if (event && event.action) {
        action = event.action;
      } else if (event && event.pathParameters && event.pathParameters.action)  {
          // get access to the path parameters when running via the API Gateway
          action = event.pathParameters.action;
      }

      return action;
    }

    // @TODO Handle url parameters
    getParameters() {}

    //
    async get(event, callback) {
      // Get the API action
      const action = this.getAction(event);

      try {
        const binanceResponse = await this.httpClient(this.binanceUrl + action);
        this.response.headers["Content-Type"] = "application/json; charset=utf-8";
        this.response.body = JSON.stringify(binanceResponse.data);

      } catch (error) {
        this.response.statusCode = 502;
        this.response.body = error.message;
      }
      callback(null, this.response)
    }
  }
  
  module.exports = Binance;
